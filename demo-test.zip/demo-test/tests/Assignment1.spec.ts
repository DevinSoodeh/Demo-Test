import {test, expect} from '@playwright/test'

test.beforeEach(async({ page }) => {
    await page.goto('https://daedalus.janniskaranikis.dev/challenges/1-press-the-button')
  });

test('Press the button', async({page}) =>{
      const pressMeButton = page.locator(':text-is("Press Me")')
      await pressMeButton.click()
      await expect(page.getByText('ASSERTME')).toBeVisible()
})


    