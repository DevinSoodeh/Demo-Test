import {test, expect} from '@playwright/test'

test.beforeEach(async({ page }) => {
    await page.goto('https://daedalus.janniskaranikis.dev/challenges/2-log-in')
  });

  test('Log in', async({page}) =>{
    const userNameField = page.locator('[placeholder="Enter your username here"]')
    const passwordField = page.locator('[placeholder="Enter your password here"]')    

    await userNameField.fill('Admin')
    await passwordField.fill('SafePass123')

    const loginButton = page.locator('button:has-text("Log In")');
    await loginButton.click()
    expect(page.getByText('ASSERTME')).toBeVisible()
   })