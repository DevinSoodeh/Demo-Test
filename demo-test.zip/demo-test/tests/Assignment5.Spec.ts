import {test, expect} from '@playwright/test'

test.beforeEach(async({ page }) => {
    await page.goto('https://daedalus.janniskaranikis.dev/challenges/5-create-a-quote')
  });

test('Create a quote', async({page}) => {

  const quoteElement = page.locator('[class="text-lg italic mb-8 select-none"]')
  const quoteText = await quoteElement.textContent() as string
  const wordsArray = quoteText.split(' ');
  
  for (const element of wordsArray)
  {
    await page.locator(`//li[text()="${element}"]`).first().dragTo(page.locator('[class="bg-slate-50 mb-6 border p-2 rounded-xl flex flex-wrap min-w-full lg:min-w-[40rem] min-h-[4rem] justify-center"]'))
  }
  expect(page.getByText('ASSERTME')).toBeVisible() 
});
  
