import {test, expect} from '@playwright/test'
import users from '../test-data/users.json'

test.beforeEach(async({ page }) => {
    await page.route('*/**/api/users' , async route => {
      await route.fulfill({
        body: JSON.stringify(users)
      })   
  })
    await page.goto('https://daedalus.janniskaranikis.dev/challenges/4-bad-data')
  });

test('Bad Data', async({page}) =>{
  await expect(page.getByText('ASSERTME')).toBeVisible()
})