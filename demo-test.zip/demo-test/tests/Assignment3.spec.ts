import {test, expect} from '@playwright/test'

test.beforeEach(async({ page }) => {
    await page.goto('https://daedalus.janniskaranikis.dev/challenges/3-mr-robot')
  });
  
test('Mr. Robot', async({ page }) => {
  
  const buttonOne = page.locator('[class="bg-red-400 border-2 border-red-700 w-24 lg:w-48 h-24 mx-4 rounded-full text-lg lg:text-2xl"]')
  const buttonTwo = page.locator('[class="bg-red-400 border-2 border-red-700 w-24 lg:w-48 h-24 mx-4 rounded-full text-2xl"]')    

  const buttonText1 = await buttonOne.locator('div').textContent() as string
  const int1 = parseInt(buttonText1, 10)

  const buttonText2 = await buttonTwo.locator('div').textContent() as string
  const int2 = parseInt(buttonText2, 10)

  for (var i = int1  ; i > 0 ; i--) {
    await buttonOne.click()
  }
  
  for (var i = int2  ; i > 0 ; i--) {
    await buttonTwo.click()
  }

  const span = page.locator('#correctddValue');
  const selectedDrink = await span.textContent() as string;

  const dropDown = page.locator('[class="border-4 border-red-400 mt-2 py-4 mb-6 px-6 rounded-xl"]');

  await dropDown.selectOption({ label: selectedDrink });  

  await expect(page.getByText('ASSERTME')).toBeVisible()
})
