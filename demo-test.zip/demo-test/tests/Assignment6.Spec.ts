import {test, expect} from '@playwright/test'

test.beforeEach(async({ page }) => {
    await page.goto('https://daedalus.janniskaranikis.dev/challenges/6-countersign')
  });

test('Countersign', async ({ page }) => {

await page.waitForTimeout(5000);

const passCodeLabel = await page.getByLabel('Your pass code');
const passCodeVal = await passCodeLabel.inputValue() as string;

const response = await page.request.post('https://daedalus.janniskaranikis.dev/api/getkey', {
  headers: {
    'Content-Type': 'text/plain',
  },
  data: passCodeVal, 
})

 const responseText = await response.text()
 const responseJson = JSON.parse(responseText)
 const keyValue = responseJson.key;
 
//enter reponse
 const responseTextField = await page.getByLabel('Your Response')
 await responseTextField.fill(keyValue)

//press submit
 const submitButton = page.locator(':text-is("Submit")')
 await submitButton.click()

 await expect(page.getByText('ASSERTME')).toBeVisible()
});
